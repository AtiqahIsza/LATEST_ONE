<?php
require_once('database_connection.php');
require_once('crypto_class.php');
require_once('datalib.php');

$Data = new Datalib();
$Crypto = new Crypto();

class Authorization
{
	public function __Construct()
	{		}
	
	public function AuthenticateLogin($loginName,$loginPass, $userType)
	{
		$Con = oci_connect('kgsm', 'kgsm', 'localhost/XE') or die('Could not connect to the database.' );
		$Data = new Datalib();
		$Crypto = new Crypto();
		
		$checkAccUser=$this->checkExistAccount_user($loginName);//Check acc user
		$checkAccAdmin=$this->checkExistAccount_admin($loginName);//Check acc admin
		$checkAccCoach=$this->checkExistAccount_coach($loginName);//Check acc admin
		//$loginName=mysqli_real_escape_string($Con, $loginName);
		//$loginPass=mysqli_real_escape_string($Con, $loginPass);
		
		if(($checkAccUser==false) && ($checkAccAdmin==false) && ($checkAccCoach==false))
		{
			echo "<script language='JavaScript'> alert('Anda Bukan Ahli. Sila Daftar Dahulu.'); window.location.href='../index.php'; </script>";
		}
			
		if($userType=="1")
		{
			$encryptPass=$Crypto->combination_encrypt($loginPass);
			$sql = "SELECT * 
					FROM administrator
					WHERE adminName='$loginName' 
					AND adminPassword='$encryptPass'";
					
			$result=oci_parse($Con, $sql) or die ('Query Failed' . oci_error($Con));
			oci_execute($result);
			$row=oci_fetch_array($result, OCI_BOTH);
				
			if (oci_num_rows($result)==1) 
			{
				session_start();	
				$_SESSION['auth']=true;					
				$_SESSION['userRole']=$row['userTypeID'];
				$_SESSION['userRoleDesc']=$row['userTypeDesc'];
				$_SESSION['userId']=$row['adminID'];
				$_SESSION['userName']=$row['adminName'];
				$_SESSION['userFullname']=$row['adminFullname'];
				$_SESSION['userIC']=$row['adminIC'];
				$_SESSION['userEmail']=$row['adminEmail'];	
				$_SESSION['userPhone']=$row['adminPhoneNo'];	
				$_SESSION['userAddress']=$row['adminAddress'];	
				$_SESSION['userPhoto']=$row['userPhoto'];	
				$_SESSION['userPhotoName']=$row['userPhotoName'];	
					
				$result=oci_parse($Con, $sql) or die ('Query Failed' . oci_error($Con));
				
				if($result)
				{
					echo "<script language='JavaScript'>alert('Anda Berjaya Masuk!');window.location.href='../home.php?val=true';</script>";	
				}
			}		
			else 
			{	
				echo "<script language='JavaScript'>alert('Anda Gagal. Sila Cuba Lagi.');window.location.href='../index.php';</script>";	
			}
		}
		
		if($userType=="2")
		{
			$encryptPass=$Crypto->combination_encrypt($loginPass);
			$sql = "SELECT * FROM participant WHERE userName='$loginName' AND userPassword='$encryptPass'";
			$result=oci_parse($Con, $sql) or die ('Query Failed' . oci_error($Con));
			oci_execute($result);
			$row=oci_fetch_array($result, OCI_BOTH);
				
			if (oci_num_rows($result)==1) 
			{
				session_start();	
				$_SESSION['auth']=true;					
				$_SESSION['userRole']=$row['userTypeID'];
				$_SESSION['userRoleDesc']=$row['userTypeDesc'];
				$_SESSION['userId']=$row['userID'];
				$_SESSION['userName']=$row['userName'];
				$_SESSION['userFullname']=$row['userFullname'];
				$_SESSION['userIC']=$row['userIC'];
				$_SESSION['userEmail']=$row['userEmail'];	
				$_SESSION['userPhone']=$row['userPhone'];	
				$_SESSION['userAddress']=$row['userAddress'];
				$_SESSION['userPhoto']=$row['userPhoto'];	
				$_SESSION['userPhotoName']=$row['userPhotoName'];		
					
				
				$sql2 = "UPDATE participant SET userStatus='ACTIVE' WHERE username='$loginName' AND userPass='$encryptPass'";
				$result=oci_parse($Con, $sql) or die ('Query Failed' . oci_error($Con));
				
				if($result)
				{
					echo "<script language='JavaScript'>alert('Anda Berjaya Masuk! Status Anda Telah Dikemaskini.');window.location.href='../home.php?val=true';</script>";		
				}
				
			}
			else 
			{	
				echo "<script language='JavaScript'>alert('Anda Gagal. Sila Cuba Lagi.');window.location.href='../index.php?val=true';</script>";	
			}
		}
		
		if($userType=="3")
		{
			$encryptPass=$Crypto->combination_encrypt($loginPass);
			$sql = "SELECT * 
					FROM coach
					WHERE coachName='$loginName' 
					AND coachPassword='$encryptPass'";
					
			$result=oci_parse($Con, $sql) or die ('Query Failed' . oci_error($Con));
			oci_execute($result);
			$row=oci_fetch_array($result, OCI_BOTH);
				
			if (oci_num_rows($result)==1) 
			{
				session_start();	
				$_SESSION['auth']=true;					
				$_SESSION['userRole']=$row['userTypeID'];
				$_SESSION['userRoleDesc']=$row['userTypeDesc'];
				$_SESSION['userId']=$row['coachID'];
				$_SESSION['userName']=$row['coachName'];
				$_SESSION['userFullname']=$row['coachFullname'];
				$_SESSION['userIC']=$row['coachIC'];
				$_SESSION['userEmail']=$row['coachEmail'];	
				$_SESSION['userPhone']=$row['coachPhone'];	
				$_SESSION['userAddress']=$row['coachAddress'];	
				$_SESSION['userPhoto']=$row['userPhoto'];	
				$_SESSION['userPhotoName']=$row['userPhotoName'];	
					
				$result=oci_parse($Con, $sql) or die ('Query Failed' . oci_error($Con));
				
				if($result)
				{
					echo "<script language='JavaScript'>alert('Anda Berjaya Masuk!');window.location.href='../home.php?val=true';</script>";	
				}
			}		
			else 
			{	
				echo "<script language='JavaScript'>alert('Anda Gagal. Sila Cuba Lagi.');window.location.href='../index.php';</script>";	
			}
		}
		
		else
		{
			echo "<script language='JavaScript'>alert('Anda Salah Memasukkan Jenis Pengguna.');window.location.href='../index.php';</script>";	
		}
	}
	
	
	public function AuthenticateSignup($userName, $userPassword, $userFullname, $userIC, $userEmail, $userPhone, $userAddress, 
					$userPhotoName, $userType, $userTypeDesc)
	{
		$Con = oci_connect('kgsm', 'kgsm', 'localhost/XE') or die('Could not connect to the database.' );
		$Data = new Datalib();
		$Crypto = new Crypto();

		$checkAccUser=$this->checkExistAccount_user($userName);	
		$checkAccCoach=$this->checkExistAccount_coach($userName);
		//$userName=mysqli_real_escape_string($Con, $userName);
		//$userPass= oci_escape_string($Con, $userPass);
			
		if (($checkAccUser==true) && ($checkAccCoach==true))//Acc already exist
		{	
			echo "<script LANGUAGE='JavaScript' type='text/javascript'>window.alert('Anda Sudah Menjadi Ahli!');
		window.location.href='../login.php';</script>"; 
		}
		
		if ($userType=="2")//Acc Coach not exist yet 
		{
			$encryptPass=$Crypto->combination_encrypt($userPass);
			$sql = "INSERT INTO coach(coachName, coachPassword, coachFullname, coachIC, coachPhoneNo, coachAddress, coachEmail,
					userPhotoName, userPhoto, userType, userTypeDesc)
					VALUES('".$userName."','".$encryptPass."', '".$userFullname."', '".$userIC."','".$userPhoneNo."',  
					'".$userAddress."','".$userEmail."','".$name."',  '".$image."',  '".$userType."', '".$userTypeDesc."')";
			$result_insert=$Data->int_db_insertion($sql);
			return $result_insert;
		}
		if ($userType=="3")//Acc Participant not exist yet
		{	
			$encryptPass=$Crypto->combination_encrypt($loginPass);
			$sql = "INSERT INTO participant(userName, userPassword, userFullname, userIC, userEmail, userPhone, userAddress, 
					userPhotoName, userPhoto, userStatus, userType, userTypeDesc)
					VALUES('".$userName."','".$encryptPass."', '".$userFullnamee."', '".$userIC."','".$userEmail."',
					'".$userPhoneNo."','".$userAddress."','".$name."',  '".$image."', 'AKTIF','".$userType."', '".$userTypeDesc."')";
			/**$sql = "INSERT INTO admin(adminName, adminPass, adminFullname, adminEmail, adminPhone, adminAddress, userPhotoName, userPhoto, userStatus, userTypeID, userTypeDesc)
					VALUES('".$loginName."','".$encryptPass."', '".$fullName."', '".$email."', '".$phoneNo."',  '".$address."', '".$name."',  '".$image."', 'ACTIVE', '1', 'Administrator')";*/
			$result_insert=$Data->int_db_insertion($sql);
			return $result_insert;
		}
		
	}
	
	private function checkExistAccount_user($loginName)
	{	
		$Con = oci_connect('kgsm', 'kgsm', 'localhost/XE') or die('Could not connect to the database.' );
		
		$sql="SELECT userID FROM participant WHERE userName='$loginName' ";		
		$result=oci_parse($Con, $sql) or die ('Query Failed checkExistAccount_user' . oci_error($Con));
		oci_execute($result);
		$row=oci_fetch_array($result, OCI_BOTH);
		if (oci_num_rows($result)==1) 
		{
			return true;
		}
 
 		else 
		{
			return false;
		}
	}	
	
	private function checkExistAccount_admin($loginName)
	{	
		$Con = oci_connect('kgsm', 'kgsm', 'localhost/XE') or die('Could not connect to the database.' );
	
		$sql="SELECT adminID FROM administrator WHERE adminName='$loginName' ";		
		$result=oci_parse($Con, $sql) or die ('Query Failed checkExistAccount_admin' . oci_error($Con));
		oci_execute($result);
		$row=oci_fetch_array($result, OCI_BOTH);
		if (oci_num_rows($result)==1) 
		{
			return true;
		}
 
 		else 
		{
			return false;
		}
	}	
	
	private function checkExistAccount_coach($loginName)
	{	
		$Con = oci_connect('kgsm', 'kgsm', 'localhost/XE') or die('Could not connect to the database.' );
	
		$sql="SELECT coachID FROM coach WHERE coachName='$loginName' ";		
		$result=oci_parse($Con, $sql) or die ('Query Failed checkExistAccount_admin' . oci_error($Con));
		oci_execute($result);
		$row=oci_fetch_array($result, OCI_BOTH);
		if (oci_num_rows($result)==1) 
		{
			return true;
		}
 
 		else 
		{
			return false;
		}
	}	
	
	public function getNo($loginName, $userType)
	{	
		$Con = oci_connect('kgsm', 'kgsm', 'localhost/XE') or die('Could not connect to the database.' );
	
		if($userType=="3")
		{
			$sql="SELECT No FROM participant WHERE participantName='$loginName' ";		
			$result=oci_parse($Con, $sql) or die ('Query Failed getNoParticipant' . oci_error($Con));
			oci_execute($result);
			$row=oci_fetch_array($result, OCI_BOTH);
			if (oci_num_rows($result)==1) 
			{
				return true;
			}
			else 
			{
				return false;
			}
		}	
		else if($userType=="2")
		{
			$sql="SELECT No FROM coach WHERE coachName='$loginName' ";
			$result=oci_parse($Con, $sql) or die ('Query Failed getNoCoach' . oci_error($Con));
			oci_execute($result);
			$row=oci_fetch_array($result, OCI_BOTH);
			if (oci_num_rows($result)==1) 
			{
				return true;
			}
			else 
			{
				return false;
			}
		}
	}
	
	public function saveID($loginName, $id, $userType)
	{	
		$Con = oci_connect('kgsm', 'kgsm', 'localhost/XE') or die('Could not connect to the database.' );
	
		if($userType=="2")
		{
			$sql="UPDATE Coach SET coachID='$id' WHERE coachName='$loginName'";		
			$result=oci_parse($Con, $sql) or die ('Query Failed saveID' . oci_error($Con));
			oci_execute($result);
			$row=oci_fetch_array($result, OCI_BOTH);
			oci_close($Con);
		}
		else if($userType=="3")
		{
			$sql="UPDATE Participant SET userID='$id' WHERE userName='$loginName'";		
			$result=oci_parse($Con, $sql) or die ('Query Failed getNoParticipant' . oci_error($Con));
			oci_execute($result);
			$row=oci_fetch_array($result, OCI_BOTH);
			oci_close($Con);
		}
	}
	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
</body>
</html>
