<?php
require_once('database_connection.php');
require_once('datalib.php');
 
class Payment
{
	public function __Construct()
	{}
	
	public function getListOfPayment($userId)
	{
		$Con = mysqli_connect('localhost','root', '', 'one');
		$sql = "SELECT *
				FROM payment
				WHERE userId = '$userId'";
		//echo $sql; exit();
		$result = mysqli_query($Con,$sql) or die ();
		return $result;
		mysqli_close($Con);
	}
}
?>