<?php
$username = "kgsm";                  // Use your username
$password = "kgsm";             // and your password
$database = "localhost/XE"; 

$Con = oci_connect($username, $password, $database) or die('Could not connect to the database.' );
?>