<?php
require_once('database_connection.php');
require_once('datalib.php');
 
class Report
{
	public function __Construct()
	{}
	
	public function getNumClass($month)
	{
		$Con = mysqli_connect('localhost','root', '', 'one');
		$sql = "SELECT LENGTH(classID), classID
				FROM Classes
				WHERE to_char(classDate, 'mm') = '$month')";
		//echo $sql; exit();
		$result = mysqli_query($Con,$sql) or die ();
		return $result;
		mysqli_close($Con);
	}
	
	public function viewReport($classID)
	{
		$Con = mysqli_connect('localhost','root', '', 'one');
		$sql = "SELECT A.className, B.classID, A.coachID, C.coachName
				FROM Classes A, Participation B, Coach C
				WHERE A.classID = B.classID
				AND A.coachID = C.coachID
				AND A.classID = '$classID'";
		//echo $sql; exit();
		$result = mysqli_query($Con,$sql) or die ();
		return $result;
		mysqli_close($Con);
	}
	
	public function getListOfPaticipant($classID)
	{
		$Con = mysqli_connect('localhost','root', '', 'one');
		$sql = "SELECT A.userID, A.userName, A.userStatus
				FROM Participant A, Participation B
				WHERE A.userID = B.userID
				AND classID = $classID";
		//echo $sql; exit();
		$result = mysqli_query($Con,$sql) or die ();
		return $result;
		mysqli_close($Con);
	}
	
	public function getNumOfParticipant($classID, $month)
	{
		$Con = mysqli_connect('localhost','root', '', 'one');
		$sql = "SELECT LENGTH(userID)
				FROM Participation
				WHERE classID = (SELECT classID
                    			FROM Classes
                    			WHERE classID = '$classID'
								AND to_char(classDate, 'mm') = '$month')";
		//echo $sql; exit();
		$result = mysqli_query($Con,$sql) or die ();
		return $result;
		mysqli_close($Con);
	}
	
	public function getPayment($userId, $classID, $month)
	{
		$Con = mysqli_connect('localhost','root', '', 'one');
		$sql = "SELECT SUM(D.paymentAmount)
				FROM Payment D, Class A, Participant C
				WHERE A.classID = D.classID
				AND D.userID = C.userID
				AND D.userID = '$userId'
				AND D.classID = '$classID';
				AND to_char(A.classDate, 'mm') = '$month'";
		//echo $sql; exit();
		$result = mysqli_query($Con,$sql) or die ();
		return $result;
		mysqli_close($Con);
	}
}
?>