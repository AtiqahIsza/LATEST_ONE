<?php
require_once("../model/report_class.php");

$Report = new Report();

$activity = $_GET['activity'];

if($activity=="viewReport")
{
	$month=$_POST['month'];;

	 echo "<script LANGUAGE='JavaScript' type='text/javascript'> 
	 		window.location.href='../view/viewReport.php?month=".$month."';</script>"; 
}
?>