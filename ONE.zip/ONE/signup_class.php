<?php
require_once("model/authorization_class.php");
require_once('model/crypto_class.php');
require_once('model/datalib.php');

$Data = new Datalib();
$Crypto = new Crypto();
$Authorization = new Authorization();

$userFullname=$_POST['fname'];
$userName=$_POST['uname'];
$pass1=$_POST['psw'];
$pass2=$_POST['psw2'];
$email=$_POST['email'];	
$userPhoneNo=$_POST['phoneno'];	
$userAddress=$_POST['address'];	
$userType=$_POST['utype'];	
$userIC=$_POST['noic'];	

$name=addslashes($_FILES['image']['name']);
$image=base64_encode(file_get_contents(addslashes($_FILES['image']['tmp_name'])));

if ($pass1 != $pass2)
{	
	echo "<script language='JavaScript'>alert('Kata Laluan Tidak Sama.');window.location='index.php';</script>";	
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
	  }

/*if ($email=="" || (strpos($email, '@') != false) && (strpos($email, '.') != false))
{	
	echo "<script language='JavaScript'>alert('Emel Anda Tidak Lengkap.');window.location='index.php';</script>";	
}*/

$Access=$Authorization->AuthenticateSignup($userName);

if($Access==false){
		if ($userType=="2")//Acc Coach not exist yet 
		{
			$userTypeDesc = 'PENGAJAR';
			$encryptPass=$Crypto->combination_encrypt($pass1);
			$sql = "INSERT INTO coach(coachName, coachPassword, coachFullname, coachIC, coachPhoneNo, coachAddress, coachEmail,
					userPhotoName, userPhoto, userType, userTypeDesc)
					VALUES('".$userName."','".$encryptPass."', '".$userFullname."', '".$userIC."','".$userPhoneNo."',  
					'".$userAddress."','".$email."','".$name."',  '".$image."',  '".$userType."', '".$userTypeDesc."')";
			$result = oci_parse($Con,$sql);
			$r = oci_execute($result);
		}
		if ($userType=="3")//Acc Participant not exist yet
		{	
			$userTypeDesc = 'PESERTA';
			$encryptPass=$Crypto->combination_encrypt($loginPass);
			$sql = "INSERT INTO participant(userName, userPassword, userFullname, userIC, userEmail, userPhone, userAddress, 
					userPhotoName, userPhoto, userStatus, userType, userTypeDesc)
					VALUES('".$userName."','".$encryptPass."', '".$userFullnamee."', '".$userIC."','".$email."',
					'".$userPhoneNo."','".$userAddress."','".$name."',  '".$image."', 'AKTIF','".$userType."', '".$userTypeDesc."')";
			$result = oci_parse($Con,$sql);
			$r = oci_execute($result);
		}
}
if($r)
{
	$no = $Authorization->getNo($userName, $userType);

	if($userType=="2")
	{
		$id = 'C' . $no;
	}
	else if($userType=="3")
	{
		$id = 'P' . $no;
	}
	$saveID = $Authorization->saveID($userName, $id, $userType);
	
	if($saveID==true)
	{
		echo "<script LANGUAGE='JavaScript' type='text/javascript'>window.alert('Pendaftaran Akaun Anda Berjaya!');
	window.location.href='index.php?val=true';</script>";  
	}
}
else
{
	echo "<script LANGUAGE='JavaScript' type='text/javascript'>window.alert('Pendaftaran Akaun Anda Tidak Berjaya! Sila Cuba Lagi');
	window.location.href='index.php?val=true';</script>"; 
}
?>
